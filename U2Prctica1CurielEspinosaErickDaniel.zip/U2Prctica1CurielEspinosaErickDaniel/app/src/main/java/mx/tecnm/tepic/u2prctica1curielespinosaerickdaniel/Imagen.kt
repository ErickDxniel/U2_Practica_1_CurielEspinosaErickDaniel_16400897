package mx.tecnm.tepic.u2prctica1curielespinosaerickdaniel

import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint

class Imagen(punterolienzo: Lienzo, posX:Float, posY:Float, nombreImagen: Int){
    var x = posX
    var y = posY
    var imagen = BitmapFactory.decodeResource(punterolienzo.resources, nombreImagen)

    fun dibujar(c: Canvas){
        c.drawBitmap(imagen, x, y, Paint())
    }

    fun estaEnArea(toqueX:Float,toqueY:Float):Boolean{
        var x2 = x + imagen.width
        var y2 = y + imagen.height

        if(toqueX >= x && toqueX <= x2){
            if(toqueY >= y && toqueY <= y2){
                return true
            }
        }

        return false
    }
    /*
        fun colision(objetoB:FiguraGeometrica) : Boolean {
            var x2 = x + ancho
            var y2 = y + alto

            //Caso 1
            if(objetoB.estaEnArea(x2, y2 + alto)){
                return true
            }

            //Caso 2
            if(objetoB.estaEnArea(x, y2)){
                return true
            }

            //Caso 3
            if(objetoB.estaEnArea(x2, y)){
                return true
            }

            //Caso 4
            if(objetoB.estaEnArea(x, y)){
                return true
            }

            return false
        }
    */
    fun mover(toqueX: Float, toqueY: Float){
        x = toqueX - imagen.width/2
        y = toqueY - imagen.height/2
    }


}