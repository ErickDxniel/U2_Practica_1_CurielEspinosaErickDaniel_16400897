package mx.tecnm.tepic.u2prctica1curielespinosaerickdaniel

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.CountDownTimer
import android.view.MotionEvent
import android.view.View

class Lienzo(p: MainActivity) : View(p) {
    var puntero = p
    var trabajando  = false
    //Luna
    var Luna = FiguraGeometrica(150, 150, 650)

    // Nubes
    var nube1 = FiguraGeometrica(50, 150, 50)
    var nube2 = FiguraGeometrica(100, 152, 50)
    var nube3 = FiguraGeometrica(150, 150, 50)

    var nube4 = FiguraGeometrica(150, 198, 50)
    var nube5 = FiguraGeometrica(200, 198, 50)
    var nube6 = FiguraGeometrica(250, 198, 50)

    var nube7 = FiguraGeometrica(350, 150, 50)
    var nube8 = FiguraGeometrica(400, 152, 50)
    var nube9 = FiguraGeometrica(450, 150, 50)

    var nube10 = FiguraGeometrica(500, 198, 50)
    var nube11 = FiguraGeometrica(550, 198, 50)
    var nube12 = FiguraGeometrica(600, 198, 50)

    var nube13 = FiguraGeometrica(700, 150, 50)
    var nube14 = FiguraGeometrica(750, 152, 50)
    var nube15 = FiguraGeometrica(800, 150, 50)

    var nube16 = FiguraGeometrica(850, 198, 50)
    var nube17 = FiguraGeometrica(900, 198, 50)
    var nube18 = FiguraGeometrica(950, 198, 50)

    //Tumbas
    var icono1 = Imagen(this, 50f, 1000f, R.drawable.tumba)
    var icono2 = Imagen(this, 800f,1300f, R.drawable.tumba)
    var icono3 = Imagen(this, 150f,1800f, R.drawable.tumba)
    var icono5 = Imagen(this, 200f,1400f, R.drawable.tumba)


    // Arboles
    var tronco = FiguraGeometrica(280, 1110, 130, 180)
    var hojas  = FiguraGeometrica(350, 1050, 150)
    var hojas2 = FiguraGeometrica(350, 920,  100)


    var tronco2 = FiguraGeometrica(580,  1700, 130, 180)
    var hojas3  = FiguraGeometrica(650,  1640,  150)
    var hojas4 =  FiguraGeometrica(650,  1510 , 100)


    var tronco3 = FiguraGeometrica(750,  900,  130, 180)
    var hojas5  = FiguraGeometrica(820,  840,  150)
    var hojas6 =  FiguraGeometrica(820,  700,  100)


    var pasto = FiguraGeometrica(0,1000,1200,2000)

    //Variables Movimiento PARCA
    var xC=270f
    var yC=860f
    var incrementoX=5

    //Timer MOVIMIENTO Parca
    val timer = object : CountDownTimer(30,100){
        override fun onTick(p0: Long) {
            xC+=incrementoX
            if (xC<=-100 || xC>=1200){
                incrementoX*=-1
            }
            invalidate()
        }
        override fun onFinish() {
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val paint = Paint()
        // Fondo
        canvas.drawColor(Color.rgb(37, 40, 80))

        // Pasto
        paint.color = Color.rgb(31, 58, 61)
        pasto.pintar(canvas,paint)

        // Luna
        paint.color = Color.rgb(254, 246, 142)
        Luna.pintar(canvas, paint)

        // Nube
        paint.color = Color.rgb( 173, 183, 184)
        nube1.pintar(canvas, paint)
        nube2.pintar(canvas, paint)
        nube3.pintar(canvas, paint)
        paint.color = Color.rgb(173, 183, 184)
        nube4.pintar(canvas, paint)
        nube5.pintar(canvas, paint)
        nube6.pintar(canvas, paint)
        paint.color = Color.rgb(173, 183, 184)
        nube7.pintar(canvas, paint)
        nube8.pintar(canvas, paint)
        nube9.pintar(canvas, paint)
        paint.color = Color.rgb(173, 183, 184)
        nube10.pintar(canvas, paint)
        nube11.pintar(canvas, paint)
        nube12.pintar(canvas, paint)
        paint.color = Color.rgb(173, 183, 184)
        nube13.pintar(canvas, paint)
        nube14.pintar(canvas, paint)
        nube15.pintar(canvas, paint)
        paint.color = Color.rgb(173, 183, 184)
        nube16.pintar(canvas, paint)
        nube17.pintar(canvas, paint)
        nube18.pintar(canvas, paint)

        icono1.dibujar(canvas)
        icono2.dibujar(canvas)
        icono3.dibujar(canvas)
        //icono4.dibujar(canvas)
        icono5.dibujar(canvas)

        //PNG Movimiento
        var parca = Imagen(this, xC, yC, R.drawable.parca)
        parca.dibujar(canvas)


        //Arbol
        paint.color = Color.rgb(128, 64, 0)
        tronco.pintar(canvas, paint)
        paint.color = Color.rgb(235, 97, 35)
        hojas.pintar(canvas, paint)
        hojas2.pintar(canvas, paint)

        paint.color = Color.rgb(128, 64, 0)
        tronco2.pintar(canvas, paint)
        paint.color = Color.rgb(235, 97, 35)
        hojas3.pintar(canvas, paint)
        hojas4.pintar(canvas, paint)

        paint.color = Color.rgb(128, 64, 0)
        tronco3.pintar(canvas, paint)
        paint.color = Color.rgb(235, 97, 35)
        hojas5.pintar(canvas, paint)
        hojas6.pintar(canvas, paint)

    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        //event.action=Presione, Arrastro, Libero
        //event.x event.y
        if (event.action==MotionEvent.ACTION_DOWN){
            //Entra si se presiona
            if (trabajando==false){
                timer.start()
                trabajando=true
            }
        }
        if (event.action==MotionEvent.ACTION_MOVE) {

        }
        if(event.action==MotionEvent.ACTION_UP){

        }
        invalidate() //Vuelve a llamar al onDraw para volver a repintar
        return true
    }
}